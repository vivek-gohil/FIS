package com.fis.main.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api")
public class HelloWorldController {

	// http://localhost:8080/api/message
	@RequestMapping(value = "message" , method = RequestMethod.GET)
	public String getMessage() {
		return "Hello World From Spring Boot";
	}

	// http://localhost:8080/api/{vivekGohil}
	@RequestMapping("{text}")
	public int getLenth(@PathVariable String text) {
		return text.length();
	}
}
