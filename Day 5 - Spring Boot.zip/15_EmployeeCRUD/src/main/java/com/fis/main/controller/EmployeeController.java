package com.fis.main.controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fis.main.dao.EmployeeCRUD;
import com.fis.main.pojo.Employee;

@RestController
@RequestMapping("employeeapi")
public class EmployeeController {
	private EmployeeCRUD employeeCRUD = new EmployeeCRUD();

	@RequestMapping(value = "allemployees", method = RequestMethod.GET)
	public ArrayList<Employee> getAll() {
		ArrayList<Employee> allEmployees = employeeCRUD.getAllEmployees();
		return allEmployees;
	}

	@RequestMapping(value = "addemployee", method = RequestMethod.POST)
	public boolean addNew(@RequestBody Employee employee) {
		boolean result = employeeCRUD.addNewEmployee(employee);
		return result;
	}

	// http://localhost:8080/employeeapi/removeemployee/104
	// call the delete method of EmployeeCRUD class
	@RequestMapping(value = "removeemployee/{employeeId}", method = RequestMethod.DELETE)
	public boolean delete(@PathVariable int employeeId) {
		boolean result = employeeCRUD.deleteEmployee(employeeId);
		return result;
	}

}
