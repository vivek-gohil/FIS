package com.fis.main.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.fis.main.pojo.Employee;

public class EmployeeCRUD {

	public ArrayList<Employee> getAllEmployees() {

		try {
			// 1.Load Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			// 2.Create Connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/fisdb", "root",
					"root#123");
			if (connection != null) {
				String sql = "select * from employee_details";
				// 3.Store sql query
				PreparedStatement preparedStatement = connection.prepareStatement(sql);

				// 4. execute query
				ResultSet resultset = preparedStatement.executeQuery();
				System.out.println(resultset);

				ArrayList<Employee> employeeList = new ArrayList<Employee>();

				while (resultset.next()) {
					int employeeId = resultset.getInt("employee_id");
					String name = resultset.getString("name");
					double salary = resultset.getDouble("salary");

					Employee employee = new Employee(employeeId, name, salary);
					employeeList.add(employee);

				}
				// 5. Close the connection
				connection.close();
				return employeeList;
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	public boolean addNewEmployee(Employee employee) {
		try {
			// 1.Load Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// 2.Create Connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/fisdb", "root",
					"root#123");
			if (connection != null) {
				String query = "insert into employee_details values(?,?,?)";
				// 3. Store SQL Query
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, employee.getEmployeeId());
				preparedStatement.setString(2, employee.getName());
				preparedStatement.setDouble(3, employee.getSalary());

				// 4. Execute SQL Query on database
				int rowCount = preparedStatement.executeUpdate();

				// 5. Close the connection
				connection.close();
				if (rowCount > 0) {
					return true;
				}
			}
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Connection Failed");
			System.out.println(e.getMessage());
		}
		return false;
	}

	// code to deleteExisting employee
	public boolean deleteEmployee(int employeeId) {
		try {
			// 1.Load Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// 2.Create Connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/fisdb", "root",
					"root#123");
			if (connection != null) {
				String query = "delete from employee_details where employee_id = ?";
				// 3. Store SQL Query
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, employeeId);

				// 4. Execute SQL Query on database
				int rowCount = preparedStatement.executeUpdate();

				// 5. Close the connection
				connection.close();
				if (rowCount > 0) {
					return true;
				}
			}
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Connection Failed");
			System.out.println(e.getMessage());
		}
		return false;
	}
}
